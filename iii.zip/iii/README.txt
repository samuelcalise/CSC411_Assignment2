CSC411_Assignment2 (iii)

– Identifies you and your programming partner by name

Samuel Calise and Claudia Deverdits 

                ------------------------------

– Acknowledges help you may have received from or collaborative work you 
may have undertaken with classmates, programming partners, course staff, 
or others (ask me sometime about Otis the debugging dog)

When beginning this assignment we had troubles understanding the assignment
due to the images being posted later into the assignment's deadline. When 
trying to undertsand the library and its intended components for the assignment,
we went to Ayman's office hours. When creating and testing our vectors using macros
and traditional initialization formats, we used Rust online documentation and examples
from other online resources to independently troublshooting as a collective team.

                ------------------------------

– Identifies what has been correctly implemented and what has not

When testing and debugging our code, we came up with test files in addition to the 
provided pgm files to execute our expected results. When printing out our results in past
development, the code appeared to work as intended. To further provide our questions on our 
code's solution, we tested our past code from CSC211 which we created a sudoku checker code
which was also effective when showing our results.

                ------------------------------

– Contains the critical parts of your design checklists

Yes, please see comments in code.

                ------------------------------

– Says approximately how many hours you have spent completing the assignment

This assingment took approximately 17 hours to complete
